# Fenrir Arch

The Arch Linux installer and system integration layer for **Fenrir Desktop**. Dotfiles and the visual layer live in [Fenrir-Dots](https://github.com/sunxsaturn/Fenrir-Dots), following the installer + dotfiles architecture used by established Hyprland projects.

## One-command installation

Start from a minimal Arch Linux x86_64 installation with systemd, networking, Git and a regular sudo-enabled user. Do not preinstall KDE, GNOME or another Hyprland dotfiles distribution.

```bash
git clone --depth=1 https://github.com/sunxsaturn/Fenrir-Arch.git ~/Fenrir && cd ~/Fenrir && ./install.sh
```

The installer clones/updates Fenrir-Dots automatically into `~/.local/share/fenrir/dots`, then deploys the desktop configuration and applications. It performs a full `pacman -Syu`, enables official multilib for Steam, installs the complete gaming/audio/software profile, configures US International dead keys, persistent Ethernet Wake-on-LAN where supported, and eligible fixed data-disk mounts by UUID.

Review the confirmation prompt and pacman transaction. REAPER has its own EULA. No automatic reboot, partitioning, formatting, bootloader installation, firmware changes or file operations on data volumes are performed.

Options: `--dry-run`, `--no-ai`, `--no-storage`, `--no-wol`, `--yes`, `--help`.

## Included software

- Hyprland, Waybar, Fuzzel, Kitty, Mako, XDG portals and Thunar
- Mozilla Firefox Nightly from Mozilla's official archive, SHA-512 verified
- Steam, GameMode, MangoHud, Gamescope, 32-bit Mesa and RADV Vulkan libraries
- Heroic, RPCS3, Prism Launcher
- Discord, Spotify and Whatsie
- PipeWire, EasyEffects, QPWgraph, Guitarix, Calf LV2, REAPER and ReaPack
- Sun AI with Ollama Vulkan (no model is downloaded automatically)

Spotify/RPCS3 Flatpak builds and Whatsie are third-party packages; review their permissions and trust model before use. The default install does not require an AUR helper.

## Wallpapers

Fenrir-Dots implements 15-minute random rotation and wallpaper-derived color accents. The engine requires at least 5,000 valid landscape files (minimum 2560×1440; 3840×2160 preferred). This repository does not pretend to contain that image corpus. The Fenrir Wallpaper Catalog requires traceable rights evidence, per-asset acquisition authorization, duplicate clearance and human acceptance. The installer only downloads a supplied, validated manifest; it does not scrape or mass-download unlicensed images. See `docs/WALLPAPER-PACK.md`.

## Tests

```bash
python3 -m unittest discover -s tests -v
bash -n install.sh scripts/*.sh scripts/fenrir-enable-wol
python3 -m compileall -q scripts tests
```

No software license has been selected yet; publication does not imply a license grant for third-party materials.
